from setuptools import setup

setup(name="distribution_gb",
    version="1.0",
    description="Gaussian and Binomial Distribution",
    packages=["distribution"], 
    author= "Anurag Borah",
    author_email="anuragborah2548@gmail.com",
    zip_safe=False)