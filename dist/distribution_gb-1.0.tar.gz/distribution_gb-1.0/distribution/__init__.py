from .Gaussian_distribution import gaussian
from .Binomial_distribution import binomial
